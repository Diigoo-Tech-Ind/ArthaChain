# 1.1.0 (January 28, 2023)

This release marks `new` and `empty` as const.

# 1.0.0 (December 14, 2019)

Initial release.
