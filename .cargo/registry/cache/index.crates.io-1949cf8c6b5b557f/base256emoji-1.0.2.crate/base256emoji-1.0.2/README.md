# rust-Base256Emoji implementation
