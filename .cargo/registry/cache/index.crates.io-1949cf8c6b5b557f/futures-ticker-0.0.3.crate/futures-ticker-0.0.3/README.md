# futures-ticker - a Stream that delivers values in a regular interval

This is an implementation of the Ticker pattern on Rust futures, based
on [futures-timer](https://github.com/async-rs/futures-timer).
