/// Intermediate Representation of a rust module.
pub mod module_ir;
/// Intermediate Representation of a rust type.
pub mod type_ir;
