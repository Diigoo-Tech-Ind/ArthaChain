[![Crate][crate-image]][crate-link]
[![Docs][docs-image]][docs-link]

See the [repo root] for build status, license, rust version, etc.

# tendermint

Implementation of the [Tendermint] Blockchain Data Structures.

## Documentation

See documentation on [crates.io][docs-link].

[//]: # (badges)

[crate-image]: https://img.shields.io/crates/v/tendermint.svg
[crate-link]: https://crates.io/crates/tendermint
[docs-image]: https://docs.rs/tendermint/badge.svg
[docs-link]: https://docs.rs/tendermint/

[//]: # (general links)

[repo root]: https://github.com/informalsystems/tendermint-rs
[Tendermint]: https://github.com/tendermint/tendermint
