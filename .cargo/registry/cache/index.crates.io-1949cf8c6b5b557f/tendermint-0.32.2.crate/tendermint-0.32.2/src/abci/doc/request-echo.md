Echoes a string to test an ABCI implementation.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#echo)