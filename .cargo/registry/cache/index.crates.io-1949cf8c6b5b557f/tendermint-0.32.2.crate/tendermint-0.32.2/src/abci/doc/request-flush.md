Indicates that any pending requests should be completed and their responses flushed.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#flush)