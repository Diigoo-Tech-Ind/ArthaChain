Queries for data from the application at current or past height.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#query)