Returns events that occurred when beginning a new block.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#beginblock)