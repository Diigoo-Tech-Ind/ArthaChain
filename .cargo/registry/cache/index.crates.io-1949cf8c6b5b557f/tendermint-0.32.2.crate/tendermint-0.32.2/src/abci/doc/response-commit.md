Returns the result of persisting the application state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#commit)