Returns validator updates that occur after the end of a block.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#endblock)