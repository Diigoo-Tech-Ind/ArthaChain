Indicates that all pending requests have been completed with their responses flushed.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#flush)