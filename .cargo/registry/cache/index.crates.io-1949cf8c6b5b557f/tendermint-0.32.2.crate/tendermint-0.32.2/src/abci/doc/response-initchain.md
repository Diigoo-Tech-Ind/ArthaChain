Returned on genesis after initializing chain state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#initchain)