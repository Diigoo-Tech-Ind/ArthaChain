Returns a list of local state snapshots.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#listsnapshots)