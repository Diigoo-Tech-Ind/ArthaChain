Returns a snapshot chunk from the application.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#loadsnapshotchunk)