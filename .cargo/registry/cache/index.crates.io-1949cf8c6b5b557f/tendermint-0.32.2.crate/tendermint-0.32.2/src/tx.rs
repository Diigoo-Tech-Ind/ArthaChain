mod proof;

pub use proof::Proof;
