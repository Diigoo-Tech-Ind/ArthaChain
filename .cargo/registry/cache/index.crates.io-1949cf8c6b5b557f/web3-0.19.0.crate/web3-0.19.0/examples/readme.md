First, run ganache

    ganache-cli -b 3 -m "hamster coin cup brief quote trick stove draft hobby strong caught unable"

Using this mnemonic makes the static account addresses in the example line up

Now we can run an example

    cargo run --example contract
