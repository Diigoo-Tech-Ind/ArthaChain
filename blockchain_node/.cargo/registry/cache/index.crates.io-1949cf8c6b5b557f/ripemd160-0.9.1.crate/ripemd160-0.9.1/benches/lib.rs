#![no_std]
#![feature(test)]

digest::bench!(ripemd160::Ripemd160);
