Signals the application that it can write the queued state transitions
from the block to its state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#commit)