Signals the end of a block.

Called after all transactions, and prior to each `Commit`.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#endblock)