Requests information about the application state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#info)