Called on genesis to initialize chain state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#initchain)