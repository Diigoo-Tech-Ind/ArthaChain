Asks the application for a list of snapshots.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#listsnapshots)