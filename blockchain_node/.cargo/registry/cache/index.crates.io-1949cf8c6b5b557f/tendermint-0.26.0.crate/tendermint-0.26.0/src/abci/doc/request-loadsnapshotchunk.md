Used during state sync to retrieve snapshot chunks from peers.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#loadsnapshotchunk)