Returns the result of checking a transaction for mempool inclusion.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#checktx)