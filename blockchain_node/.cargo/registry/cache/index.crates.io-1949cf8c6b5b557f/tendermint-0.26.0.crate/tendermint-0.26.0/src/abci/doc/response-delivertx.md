Returns events that occurred while executing a transaction against the
application state.

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#delivertx)