Returns the application's response to a snapshot offer.

See also the [`Snapshot`] data type and the [ABCI state sync documentation][ssd].

[ABCI documentation](https://docs.tendermint.com/master/spec/abci/abci.html#offersnapshot)

[ssd]: https://docs.tendermint.com/master/spec/abci/apps.html#state-sync