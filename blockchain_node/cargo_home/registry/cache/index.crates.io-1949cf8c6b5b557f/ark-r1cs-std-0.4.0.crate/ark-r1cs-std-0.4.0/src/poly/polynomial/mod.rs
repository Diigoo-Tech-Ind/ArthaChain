/// Module defining data structures for univariate polynomials.
pub mod univariate;
