/// A dense univariate polynomial represented in coefficient form.
pub mod dense;
