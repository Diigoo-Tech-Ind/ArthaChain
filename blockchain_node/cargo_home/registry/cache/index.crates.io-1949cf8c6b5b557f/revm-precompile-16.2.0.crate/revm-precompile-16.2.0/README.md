### REVM Precompiles - Ethereum compatible precompiled contracts

Used inside REVM and passes all eth/tests. It supports all Ethereum hardforks.