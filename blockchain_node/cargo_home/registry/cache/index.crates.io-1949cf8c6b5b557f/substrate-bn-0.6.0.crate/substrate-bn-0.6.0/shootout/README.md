bn crate performing 20000 pairing operations

real	3m28.831s
user	3m28.797s
sys	    0m0.020s

libsnark (ALT_BN128 with USE_ASM disabled) performing 20000 pairing operations

real	2m3.656s
user	2m3.543s
sys	    0m0.007s
