pub(crate) mod function;
pub(crate) mod global;
pub(crate) mod memory;
pub(crate) mod memory_view;
pub(crate) mod table;
